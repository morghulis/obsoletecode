# -*- coding: utf-8 -*-
import hashlib


class Hashx:
    """
    Usage:
        Hashx(<string or file-like object>).<algorithm name>.<format of value>
    eg. 
        hashvalue = Hashx(f=fobj).md5.hexdigest
        hashvalue = Hashx(s=object'string to be hashed').sha1.hexdigest
    """
    class _hash_value_:
        def __init__(self, hasher):
            self.value = hasher

        def hexdigest(self):
            return self.value.hexdigest()

    def __init__(self, s=None, f=None):
        if f is not None:
            self.f = f
        elif s is not None:
            self.s = s
        else:
            raise "Invalid data provided"

    def _get_hash_value_(self, hashtype):
        algorithm = getattr(hashlib, hashtype, None)
        if algorithm is None:
            raise "Unknown algorithm required"
        hasher = algorithm()

        f = getattr(self, 'f', None)
        if f is not None:
            data = f.read(10240)
            while data:
                hasher.update(data)
                data = f.read(10240)
        else:
            hasher.update(self.s)
        return self._hash_value_(hasher)

    # for some specific algorithm, eg. MD5, SHA-1
    def get_md5(self):
        return self._get_hash_value_(hashtype='md5')
    md5 = property(fget=get_md5)

    def get_sha1(self):
        return self._get_hash_value_(hashtype='sha1')
    sha1 = property(fget=get_sha1)

