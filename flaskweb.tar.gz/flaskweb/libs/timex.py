# -*- coding:utf-8 -*-
import time
from langx import enum


class Timeutils:
    class _time_struct:
        def __init__(self, t):
            self.year = t.tm_year
            self.month = t.tm_mon
            self.day = t.tm_mday
            self.hour = t.tm_hour
            self.minute = t.tm_min
            self.second = t.tm_sec


    time_unit = enum('Time_Units',
        year=1, month=2, day=3,
        hour=4, minute=5, second=6,
        millisecond=7)

    def __init__(self, strtime=None, utctime=None):
        if strtime is not None:
            self._utctime = time.mktime(
                time.strptime(strtime, '%Y-%m-%d %H:%M:%S'))
        elif utctime is not None:
            self._utctime = utctime
        else:
            self._utctime = time.time()

    def utc_time(self):
        return self._utctime

    def get_gmtime(self):
        return self._time_struct(time.gmtime(self._utctime))
    gm = property(fget=get_gmtime)

    def get_localtime(self):
        return self._time_struct(time.localtime(self._utctime))
    local = property(fget=get_localtime)