# -*- coding:utf-8 -*-

def printf(*args):
    for arg in args:
        print arg,
    print '\n',


def enum(name, **kwargs):
    return type(name, (), dict(**kwargs))