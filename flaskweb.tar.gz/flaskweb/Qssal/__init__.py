# -*- coding:utf-8 -*-
from flask import Flask
import options

from langx import *
import os

# global app instance
app = Flask(__name__)


def start(start_path, *args):
    def app_init(rootpath):
        # load options from files and database
        app.config.from_object(options)
        app.config["ROOT_PATH"] = rootpath

        from contextlib import closing
        import sqlite3

        filedb = os.path.join(app_path, options.DATABASE)

        with closing(sqlite3.connect(filedb)) as db:
            rs = db.execute(
                "select id, name, time_stamp from tbl_roles").fetchall()
            app.config["roleset"] = {
                "stamp": max([ t[2] for t in rs]),
                "roles": { row[0]:row[1].strip() for row in rs } # for reverse query
            }

        # setup handlers for action in runtime
        from reqx import before_request, teardown_request

        # setup url-mapping handlers
        from views import homepage
        from views.auth import login
        from views.sheet import list_sheets


    # root path of app
    app_path = os.path.join(start_path, __name__)

    if 'initdb' in args:
        create_database(os.path.join(app_path, options.DATABASE))
    else:
        app_init(app_path)
        app.run()


def create_database(filedb):
    if os.path.isfile(filedb):
        printf("Database |%s| exists."%(options.DATABASE))
        answer = raw_input("Clear all data to continue?(yes/no)").lower()
        if answer != 'y' and answer != 'yes':
            return
        os.remove(filedb)

    from contextlib import closing
    import sqlite3

    with closing(sqlite3.connect(filedb)) as db:
        with app.open_resource("schema.sql", mode="r") as fsql:
            db.cursor().executescript(fsql.read())
        db.commit()
    printf("Database is initialized successfully.")