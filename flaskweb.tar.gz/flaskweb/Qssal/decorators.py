# -*- coding: utf-8 -*-
from functools import wraps
from flask import redirect, url_for
from flask import session


def login_required(f):
    @wraps(f)
    def wrapper(*args):
        if "user" in session.keys():
            return f(*args)
        else:
            return redirect(url_for("login"))
    return wrapper


def role_required(roles=[]):
    def decorator(f):
        @wraps(f)
        def wrapper(*args):
            if len(roles) > 0:
                for name in roles:
                    if name in session['user']['roles'].keys():
                        continue
                    else:
                        return make_response('No permission required')
                #     if not (name in app.config['roleset']['roles']):
                #         return make_response("Threatening Error:no such a role")




                # for name in roles:
                #     if name in g.roleset["roles"]:
                #         role = g.roleset['roles'][name]
                #         if role in session['user']['roles']:
                #             continue
                #         else:
                #             return make_response(
                #                 'No permission required')
                #     else:
                #         return make_response(
                #             "Threatening Error: no such a role")
            return f(*args)
            
        return wrapper
    return decorator