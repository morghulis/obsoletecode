# -*- coding: utf-8 -*-
from flask import redirect
from flask import request, session, g
from flask import render_template
from flask import make_response

from Qssal import app
from Qssal.decorators import login_required, role_required

from timex import Timeutils
from hashx import Hashx

from werkzeug.utils import secure_filename
import os


@app.route('/sheets/list/')
@login_required
@role_required(roles=[ 'sheets_manager'])
def list_sheets():
    rs = g.db.execute(
        "select id, year_month, active from tbl_sheets where user=?", (session['user']['id'], )
        ).fetchall()
    sheets = [
        {
            'id':row[0],
            'year_month':row[1],
            'active':row[2]
        } for row in rs
    ]
    return render_template("sheets.html", sheets=sheets)


@app.route('/sheet/add/', methods=['GET', 'POST'])
@login_required
@role_required(roles=[ 'sheets_manager'])
def add_sheet():
    def is_valid_format(year, month):
        try:
            iyear = int(year)
            imonth = int(month)
            if iyear <= Timeutils().local.year + 1 and iyear > 1900:
                if imonth >= 1 and imonth <= 12:
                    return True
        finally:
            return False

    def is_allowed_file(filename):
        print filename, filename.rsplit('.')[0]
        if '.' in filename:
            if filename.rsplit('.')[-1] in app.config['ALLOW_UPLOAD_FILETYPES']:
                return True
        return False

    if request.method == "POST":
        year = request.form['year'].strip()
        month = request.form['month'].strip().lstrip('0')
        sheetfile = request.files['sheetfile']

        if (not is_valid_format(year, month)) and 
            (not is_allowed_file(sheetfile.filename)):
            g.err_message = "Invalid filetype" 
        else:
            # save the uploaded file and hash it
            relname = os.path.join(
                os.path.normpath(app.config['UPLOAD_FOLDER']),
                secure_filename(sheetfile.filename)
                )
            filename = os.path.join(
                app.config['ROOT_PATH'],
                relname 
                )

            sheetfile.save(filename)
            with file(filename) as fsheet:
                hashvalue = Hashx(f=fsheet).sha1.hexdigest()

            # record the uploaded file
            g.db.execute(
                "insert or ignore into tbl_files (uri, sha1) \
                    values (?, ?)",
                (relname, hashvalue)
                )
            g.db.commit()

            rs = g.db.execute(
                "select id from tbl_files where sha1=?", 
                (hashvalue,)
                ).fetchall()
            if len(rs) < 1:
                g.err_message = "Error found in above action"
            else:
                fid = rs[0][0]

               

                # Parse .xls file and add salary record into tbl_salary
                # todo
                

                # record sheet
                g.db.execute(
                    "insert or ignore into tbl_sheets (file, user, year_month \
                        values (?, ?, ?)",
                    (fid, session['user']['id'], '%s-%02d'%(year, int(month))
                    # todo: to be integritied
                    )
            


            return make_response('todo: add a sheet')
    else:
        now = Timeutils().local
        year = now.year
        month = now.month

    g.default_year = year
    g.default_month = month

    return render_template("add_sheet.html")


@app.route('/sheet/<sheetid>/delete/')
def delete_sheet(sheetid):
    return make_response('todo: delete a sheet')


@app.route('/sheet/<sheetid>/edit/')
def edit_sheet(sheetid):
    return make_response('todo: edit a sheet')