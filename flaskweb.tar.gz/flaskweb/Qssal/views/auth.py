# -*- coding:utf-8 -*-
from Qssal import app
from flask import redirect, url_for
from flask import request, session, g
from flask import render_template
from flask import make_response
from Qssal.decorators import login_required

import string


@app.route('/login/', methods=['GET', 'POST'])
def login():
    def iscellphone(name):
        if len(name) != 11:
            return False
        for c in name:
            if not (c in string.digitals):
                return False
        return True

    def setup_user(id, name):
        rs = g.db.execute(
            "select role, time_stamp from tbl_user_role \
                where user=?", (id,)
            ).fetchall()

        roles = app.config['roleset']['roles']


        session["user"] = {
            "id": id,
            "name": name,
            "roles_stamp": max([ row[1] for row in rs ]),
            "roles": { roles[row[0]]:row[0] for row in rs }
        }

    if 'user' in session.keys():
        return redirect(url_for('homepage'))

    if request.method == 'POST':
        siname = request.form['siname'].strip()
        passwd = request.form['passwd'].strip()

        sifield = "cellphone" if iscellphone(siname) else "username"

        rs = g.db.execute(
            "select id, username, password from tbl_users \
                where %s=?"%sifield, (siname,)
            ).fetchall()

        g.siname =siname
        if len(rs) == 1:
            if rs[0][2] == passwd:
                setup_user(id=rs[0][0], name=rs[0][1])
                return redirect(url_for("homepage"))
            else:
                g.err_incorrect_password = True
        elif len(rs) == 0:
            g.err_no_such_user = True
        else:
            raise "Conflict found in database: tbl_users"
    return render_template("login.html")


@app.route('/logout/')
@login_required
def logout():
    if 'user' in session.keys():
        session.pop('user')
    return redirect(url_for("homepage"))


@app.route('/user/show/')
@login_required
def show_user():
    return render_template("user_details.html")