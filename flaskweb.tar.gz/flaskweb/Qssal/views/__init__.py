# -*- coding:utf-8 -*-
from Qssal import app
from Qssal.decorators import login_required
from flask import url_for, redirect, render_template
from flask import make_response

from timex import Timeutils


@app.route('/')
@login_required
def homepage():
    # return redirect(url_for("show_salary", year=Timeutils().local.year))
    # return make_response("%s"%(Timeutils().local.year))
    return render_template('base.html')



@app.route('/salary/<year>/')
def show_salary(year):
    return make_response(
        "todo: list salary item in the specific year")