# -*- coding: utf-8 -*-
from Qssal import app
from flask import g

import sqlite3 ,os


@app.before_request
def before_request():
    g.db = sqlite3.connect(
        os.path.join(
            app.config["ROOT_PATH"],
            app.config["DATABASE"]
            ))
    


@app.teardown_request
def teardown_request(exception):
    db = getattr(g, "db", None)
    if db is not None:
        db.close()