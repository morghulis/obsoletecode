# -*- coding:utf-8 -*-
DATABASE = "database.db"
DEBUG = True
SECRET_KEY = "development key" 

UPLOAD_FOLDER = "./repository/"
ALLOW_UPLOAD_FILETYPES = set(['xls', 'txt'])