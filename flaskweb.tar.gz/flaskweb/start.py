# -*- coding:utf-8 -*-
import os, sys


def add_xlibs(libpaths=[]):
    for libpath in libpaths:
        sys.path.append(libpath)


def get_appargs():
    case_sensitive = '--case-sensitive'
    args = []
    if len(sys.argv) > 1:
        if not (case_sensitive in sys.argv[1:]):
            args = [ arg.lower() for arg in sys.argv[1:]]
        else:
            args = sys.argv[1:].remove(case_sensitive)
    return tuple(args)


if __name__ == '__main__':
    start_path = os.path.dirname(os.path.realpath(sys.argv[0]))

    # add path/paths for exlibs
    add_xlibs([
            os.path.join(start_path, 'libs')
        ])
    
    # start app service for web
    __import__('Qssal').start(start_path, *get_appargs())
