# -*- coding:utf-8 -*-

LIBS = [
    "../lib",
]

APPS = [
    # {
    #     "name": "appname",
    #     "host": "0.0.0.0",
    #     "port": 8000
    # },
    {
        "name": "sso",
        "host": "0.0.0.0",
        "port": 8000
    },
]
