# -*- coding:utf-8 -*-
from __future__ import unicode_literals
import json
import tempfile, os, shutil

class JSONConfig(object):
    @staticmethod
    def load(filename, encoding='utf-8'):
        with open(filename) as f:
            content = f.read()
        return json.loads(content, encoding=encoding)

    @staticmethod
    def dump(filename, json_dict, encoding='utf-8'):
        tmpfile = tempfile.mktemp()
        with open(tmpfile, 'w') as f:
            json.dump(json_dict, f)
        if os.path.getsize(tmpfile) > 0:
            shutil.copyfile(tmpfile, filename)
        os.remove(tmpfile)

class JsonConfig(object):
    def __init__(self, filename, encoding='utf-8'):
        self.config_file = filename
        self.encoding = encoding
        self.json_dict = {}

    def load(self):
        self.json_dict = JSONConfig.load(self.filename, self.encoding)

    def dump(self):
        JSONConfig.dump(self.filename, self.json_dict, self.encoding)

    def __getattr__(self, name):
        return self.json_dict[name]
