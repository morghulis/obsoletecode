# -*- coding:utf-8 -*-
class Enum(object):
    def __new__(cls, clsname, mbrstr):
        print "fdsa"
        mbrs = mbrstr.split()
        return type(clsname, (object,), 
            { mbrs[i]:i+1 for i in range(len(mbrs)) } )