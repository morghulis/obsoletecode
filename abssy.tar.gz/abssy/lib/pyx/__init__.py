# -*- coding:utf-8 -*-
__all__ = ['version', ]

version = '0.0.1'