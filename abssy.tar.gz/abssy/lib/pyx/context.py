# -*- coding:utf-8 -*-
class ContextDocker(object):

    def __init__(self, **kwargs):
        self.__dict__['_default_kvs'] = kwargs
        self.__dict__['_var_space'] = {}
        self.reset()
        
    def reset(self):
        self.__dict__['_var_space'] = {}
        self.__dict__['_var_space'].update(
            self.__dict__['_default_kvs'])

    def __setattr__(self, name, value):
        self.__dict__['_var_space'][name] = value

    def __getattr__(self, name):
        return self.__dict__['_var_space'][name]

    def docker(self, method):
        def wrapper(*args, **kwargs):
            return method(*args, **kwargs)
        return wrapper