# -*- coding:utf-8 -*-

def printf(*args):
    for arg in args:
        print arg,

def println(*args):
    printf(*args)
    print ''