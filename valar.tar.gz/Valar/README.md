Valar
=====
Some utilities are provided in here, which contain of:
  libraries for various languages or kits
  utilities for development, eg. shell-scripts, applications, etc.
  and so on.
