function DialogGroup(maxz){

    this.maxz = arguments[0] ? arguments[0]: 1000;

    this.mask = (function(){
        var elem = $(document.createElement("div")); 
        // elem.addClass("mask"); 
        elem.css({
            "display": "none";
            "position": "absolute";
            "top": "0%";
            "left": "0%";
            "width": "100%";
            "height": "100%";
            "background-color": "grey";
            "-moz-opacity": "0.1";
            "opacity": ".10";
        });
        $("body").append(elem);
        return elem;
    })();
}

function Dialog(pattern, dlggrp){
    this.group = dlggrp;
    this.obj = $(pattern);

    this.show = function(){
        this.group.mask.css("display", "block");
        this.group.mask.css("z-index", this.group.maxz++);

        this.obj.css("display", "block");
        this.obj.css("z-index", this.group.maxz++);

        this.onShow();
    };

    this.close = function(){
        this.onClose();

        this.obj.css("display", "none");
        this.group.maxz--;

        this.group.mask.css("display", "none");
        this.group.maxz--;
    };

    this.onShow = function(){
        //
    };

    this.onClose = function(){
        //
    };
}

// $(function(){
//     $("#testbtn").click(function(){
//         (new Dialog("#dialog", new DialogGroup())).show();
//     });
// });