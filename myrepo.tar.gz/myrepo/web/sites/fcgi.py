# -*- coding:utf-8 -*-
from flup.server.fcgi import WSGIServer
from Qssal import app

import os, sys
import pyx.logx


logger = pyx.logx.getLogger(
    'Qssal', 
    configs=[
        pyx.logx.FileConfig(
            logfile=os.path.join(os.path.dirname(sys.argv[0]), 'Qssal.log')
        ),
        pyx.logx.ConsoleConfig()
    ]
)


if __name__=='__main__':
    WSGIServer(app, bindAddress=('127.0.0.1', 8008)).run()
    # app.run(host="127.0.0.1", port=8001)