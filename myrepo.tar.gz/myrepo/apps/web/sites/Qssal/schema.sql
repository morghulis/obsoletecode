-- Global options
pragma foreign_keys=true;


-- Schema for tables

--
-- Tables for universal purposes
--

drop table if exists tbl_users;
create table if not exists tbl_users (
    id integer primary key autoincrement,
    username text not null unique,
    password text not null,
    -- values in the following field must be consisted of digitals.
    cellphone varchar(11) unique,
        -- check (length(cellphone)=11 and typeof(cellphone)='integer')
    description text,
    active integer check (active = 0 or active = 1) default (1)
); -- * username, password

drop table if exists tbl_roles;
create table if not exists tbl_roles (
    id integer primary key autoincrement,
    name text not null unique,
    comment text,
    time_stamp real not null default (datetime('now', 'localtime'))
); -- * name

drop table if exists tbl_user_role;
create table if not exists tbl_user_role (
    user references tbl_users(id)   on delete cascade
                                    on update cascade,
    role references tbl_roles(id)   on delete cascade
                                    on update cascade,
    comment text,
    time_stamp real not null default (datetime('now', 'localtime')),
    constraint pk_link primary key (user, role)
); -- * user, role

drop table if exists tbl_files;
create table if not exists tbl_files (
    id integer primary key autoincrement,
    uri text not null unique,
    sha1 text not null unique,
    description text
); -- * uri, sha1

drop table if exists tbl_favorites;
create table if not exists tbl_favorites (
    user references tbl_users(id)   on delete cascade
                                    on update cascade,
    json_content text,
    constraint pk_user primary key (user)
);



-- Tables for Qssal
--

drop table if exists tbl_sheets;
create table if not exists tbl_sheets (
    id integer primary key autoincrement,
    file references tbl_files(id)   on delete restrict
                                    on update cascade,
    user references tbl_users(id)   on delete restrict
                                    on update cascade,
    time_stamp real not null default (datetime('now', 'localtime')),

    year integer not null,
    month integer not null,
    title text not null,
    pattern text not null,
    active integer check (active = 0 or active = 1) default (0)
); -- * file, user, year_month, pattern, active

drop table if exists tbl_salary;
create table if not exists tbl_salary (
    id integer primary key autoincrement,
    sheet references tbl_sheets(id) on delete cascade
                                    on update cascade,
    user references tbl_users(id)   on delete restrict
                                    on update cascade,
    data text not null
);

drop table if exists tbl_sms;
create table if not exists tbl_sms (
    salary references tbl_salary(id) on delete no action
                                     on update cascade,
    cellphone text,
    content text,
    time_added real not null default (datetime('now', 'localtime')),
    time_submitted real,
    reason text,
    constraint pk_link primary key (salary, cellphone)
);



-- Initialize tables

insert into tbl_users (username, password)
    values ('admin', 'admin');

insert into tbl_roles (name)
    values ('sheet_manager');
insert into tbl_roles (name)
    values ('user_manager');

insert into tbl_user_role (user, role)
    select tbl_users.id, tbl_roles.id from tbl_users, tbl_roles
        where
        tbl_users.username='admin' and tbl_roles.name='sheet_manager';
insert into tbl_user_role (user, role)
    select tbl_users.id, tbl_roles.id from tbl_users, tbl_roles
        where
        tbl_users.username='admin' and tbl_roles.name='user_manager';



-- add user
begin transaction;
insert into tbl_users (username, password) values( 'Grissom', '123');
insert into tbl_users (username, password) values( 'Arya', '123');
insert into tbl_users (username, password) values( 'Theon', '123');
commit transaction;