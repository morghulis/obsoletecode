# -*- coding: utf-8 -*-
import xlrd
from errors import *


class Qson:
    @staticmethod
    def dump(lst):
        list_converted = [ 
            e if isinstance(e, str) or isinstance(e, unicode) 
            else e.__repr__() 
            for e in lst
            ]
        # print '--------------'
        # print list_converted
        return '|'.join([ escape(e) for e in list_converted ])

    @staticmethod
    def load(s):
        return [ unescape(e) for e in s.split('|')]

def escape(s):
    return s.replace('/', '//').replace('|', '/s')

def unescape(s):
    ns = []
    escmode = False
    for c in s:
        if escmode:
            if c == 's':
                ns.append('|')
            elif c == '/':
                ns.append('/')
            else:
                raise Exception()
            escmode = False
        else:
            if c == '/':
                escmode = True
            else:
                ns.append(c)
    return ''.join(ns)


    return s.replace('/s', '|').replace('//', '/')

# def escape(s):
#     return s.replace('/', '//').replace('|', '/s')

# def unescape(s):
#     return s.replace('/s', '|').replace('//', '/')


class SalarySheet:
    def __init__(self, sheetfile):
        try:
            # self.__cursor__ = 0
            sheets = xlrd.open_workbook(sheetfile).sheets()
            for sheet in sheets:
                if sheet.nrows < 5:
                    continue
                title = sheet.row_values(0)[0].strip()
                if '工资单'.decode('utf-8') in title:
                    self.year = int(title[:4])
                    self.month = int(title[5:7])
                    self.title = title
                    self.sheet = sheet

                    self.fields = self._get_fields()
                    # print self.fields
                    if not ('姓名'.decode('utf-8') in self.fields):
                        raise QssalError('No expected sheet in the file given')

                    break
            if getattr(self, 'sheet', None) is None:
                raise QssalError('No expected sheet in the file given')
        except QssalError, e:
            raise e
            # raise InvalidFileformatError("A broken file given")

    # def __iter__(self):
    #     return self

    # def next(self):
    #     if self.__cursor__ < len(self.nrows - 4):
    #         self.__cursor__ += 1 
    #         return self.row(self.__cursor__ - 1)
    #     else:
    #         self.__cursor__ = 0
    #         raise StopIteration

    def _get_fields(self):
        # print [ field.strip() for field in self.sheet.row_values(2) ]
        return [ field.strip() for field in self.sheet.row_values(2) ]

    def get_pattern(self):
        return Qson.dump(self.fields)
        # print self.fields
        # return '.'.join([ escape(e) for e in self.fields])
    pattern = property(fget=get_pattern)

    def row(self, i):
        # return self.sheet.row_values(i+4)
        # print self.sheet.row_values(5)[0]
        # print i
        return SalarySheet.row_x(self.sheet.row_values(i+4), self.fields)

    def _get_rows(self):
        return [ self.row(i) for i in range(self.nrows)]
    rows = property(fget=_get_rows)

    def _get_nrows(self):
        return self.sheet.nrows - 4
    nrows = property(fget=_get_nrows)


    class row_x:
        def __init__(self, row, fields):
            self.raw_row = row
            self.fields = fields
            self.__cursor__ = 0

        def __getitem__(self, k):
            if isinstance(k, int):
                return self.raw_row[k]
            else:
                return self.raw_row[self.fields.index(k)]

        def __str__(self):
            return self.raw_row.__str__()

        def __iter__(self):
            return self

        def next(self):
            if self.__cursor__ < len(self.raw_row):
                self.__cursor__ += 1 
                return self.raw_row[self.__cursor__ - 1]
            else:
                self.__cursor__ = 0
                raise StopIteration

    # print dir(xlrd)
    # sheets = xlrd.open_workbook('2.xls').sheets()
    # print len(sheets)

    # print dir(sheets[0])

    # sheet = sheets[0]

    # print sheet.row_values(0)[0]


if __name__=='__main__':
    def Main():
        sheet = SalarySheet('2.xls')
        print sheet.row(0)[1]
        rx = sheet.row(1)

        lst = []

        for e in rx:
            print e,
            lst.append(e)
        print ''
        print len(lst)
        print rx[28]
        print rx[2]
        print rx['姓名'.decode('utf-8')]
        print sheet.pattern



        # sheet = xlrd.open_workbook('2.xls').sheets()[0]
        # print dir(sheet)

        # print sheet.sheet.nrows

        for row in sheet.rows:
            for field in row:
                pass
            #     print field,
            # print '\n'

        print '##########################'

        for field in sheet.row(140):
            print field,
        print '\n'

        lst = [ e for e in sheet.row(140)]
        print '***********'
        s = Qson.dump(sheet.row(140))
        print s
        # print Qson.load(s)

        # lst = Qson.load(sheet.pattern)
        # for e in lst:
        #     print e,


    Main()