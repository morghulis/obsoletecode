# -*- coding: utf-8 -*-
# from Qssal import app

import urllib2, urllib
import threading, sqlite3
from pyx.timex import TimeX
from pyx.logx import getLogger
from options import *
# import Qssal

logger = getLogger('Qssal')


def sendsms(cell, message, username=SMS_USERNAME, password=SMS_PASSWORD, encoding="gbk", source_encoding="utf-8"):
    def _(s, transcode=False, src_encode=source_encoding, dst_encode=encoding):
        if transcode:
            return s.decode(src_encode).encode(dst_encode)
        else:
            return s.encode(dst_encode)

    # print cell, message, username, password
    data = urllib.urlencode({
            "tel": cell,
            "content": _(message),
            "userName": _(username),
            "userPass": _(password)
        })

    default_headers = {
            "Accept ": "text/html ",
            "Content-type ": "text/html ",
            "Connection ": "close ",
            "Content-Length ": len(data),
            "Cache-Control": "no-cache",
            "Pragma": "no-cache"
        }

    request = urllib2.Request(
        url = SMS_SERVICE,
        data = _(data),
        headers= default_headers
        )

    try: 
        logger.info("{%s}{%s}"%(cell, message))
        print _(data)
        # resp = urllib2.urlopen(request, timeout=3)
        return ('ok', None)
    except urllib2.HTTPError, e:
        return ('http_err', e.code)
    except urllib2.URLError, e:
        return ('url_err', e.reason)
    except Exception, e:
        return ('unknown exception', e.message)


class BackStageSender(threading.Thread):
    def __init__(self, filedb):
        threading.Thread.__init__(self)
        self.daemon = True
        self.condition = threading.Condition()

        self.filedb = filedb

    def notify(self):
        self.condition.acquire()
        self.condition.notify()
        self.condition.release()

    def run(self):
        self.db = sqlite3.connect(self.filedb)
        self.condition.acquire()
        while True:
            print 'aaaa'
            self.condition.wait(SMS_SCANPERIOD_SECONDS)
            print 'bbbbb'

            dt = TimeX().local
            today_start ='%d-%02d-%d 00:00:00'%(dt.year, dt.month, dt.day )

            rs = self.db.execute(
                "select cellphone, content, salary from tbl_sms where \
                    time_added >= ? and \
                    time_submitted is null and \
                    cellphone is not null",
                    (today_start,)
                ).fetchall()
            # print len(rs)

            # print "lengof of rs:", len(rs)
            for sms in rs:
                # print sms
                # print sms
                cellphone = sms[0]
                content = sms[1]
                salary = sms[2]

                print "cellphone:", cellphone

                status, _ = sendsms(cellphone, content)
                print "status:", status
                # status, _ = 'ok', None
                # print content
                if status == 'ok':
                    self.db.execute(
                        "update or ignore tbl_sms set \
                            time_submitted=datetime('now', 'localtime'), \
                            reason=? \
                            where salary=?",
                            ("ok", salary)
                        )
                else:
                    self.db.execute(
                        "update or ignore tbl_sms set \
                            reason=? \
                            where salary=?", 
                            ("No service for sms is ready.", salary)
                        )
            self.db.commit()            

        self.condition.release()
        self.db.close()


if __name__=='__main__':
    sendsms('111111', 'fdssdhjkvxk')
    sendsms('33533', '所有的中文，都是变成了%3F，明显不是'.decode('utf-8'))