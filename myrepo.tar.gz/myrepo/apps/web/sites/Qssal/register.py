# -*- coding:utf-8 -*-
from flask import g, session

from Qssal import app
from dboper import get_connection


@app.before_request
def before_request():
    g.db = get_connection()
    g.db.execute("pragma foreign_keys=True")
    g.db.commit()

    if "user" in session.keys():
        g.roles = session["user"]["roles"]


@app.teardown_request
def teardown_request(exception):
    db = getattr(g, "db", None)
    if db:
        db.close()