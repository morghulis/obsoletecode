# -*- coding:utf-8 -*-
# from Qssal import app
# import dboper

__all__ = [
    "get_roleset_updated",
    "get_user_roles_updated"
]


class _Roleset(dict):pass
    # rev = -1

class _User_roles(dict):pass
    # rev = -1


def _load_roleset(db, rev):
    rs = db.execute(
        "select name, id from tbl_roles where name != 'rev'"
        ).fetchall()

    roles = _Roleset()
    for role in rs:
        roles[role[0]] = role[1]

    roles['rev'] = rev

    return roles


def _load_user_roles(db, uid, rev):
    rs = db.execute(
        "select tbl_roles.name \
            from tbl_roles, tbl_user_role \
            where tbl_user_role.user=? and tbl_roles.id=tbl_user_role.role",
            (uid,)
        ).fetchall()

    urs = _User_roles()
    for r in rs:
        urs[r[0]] = True
    urs["rev"] = rev

    return urs


def get_roleset_updated(db, roleset=None):
    if roleset:
        return _load_roleset(db, roleset["rev"]+1)
    else:
        return _load_roleset(db, 0)


def get_user_roles_updated(db, roleset, uid, urs=None):
    if urs is None:
        # create a new pair of user-role
        return _load_user_roles(db, uid, roleset["rev"])
    else:
        if urs["rev"] < roleset["rev"]:
            return _load_user_roles(db, uid, roleset["rev"])
        else:
            return urs