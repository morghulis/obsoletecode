# -*- coding:utf-8 -*-
from Qssal import app
from flask import redirect, url_for, render_template, abort
import os, sys
# import sqlite3
from contextlib import closing
from dboper import get_connection


@app.route('/')
def homepage():
    return redirect(url_for('install'))


@app.route('/install/')
def install():
    def pre_install():
        filedb = app.path.root(app.config['DATABASE'])

        if os.path.isfile(filedb):
            os.remove(filedb)

    pre_install()

    with closing(get_connection()) as db:
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

    return render_template("installation.html")


@app.route('/reset/')
def reset():
    import sys
    sys.exit(-1)
    abort(404)

    # import subprocess

    # subprocess.popen('service restart')