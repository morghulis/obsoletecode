# -*- coding:utf-8 -*-
import os, re
import random
import string
import shutil


__all__ = [
    'Path',
    'Rand'
]


class Path:
    def __init__(self, app):
        self._app = app

    def _join_path(self, basename, relname):
        return os.path.realpath(
            os.path.join(self._app.config[basename], relname)
            )

    def root(self, name):
        return self._join_path('APP_FOLDER', name)

    def cached(self, name):
        return self._join_path('CACHE_FOLDER', name)

    def stored(self, name):
        return self._join_path('UPLOAD_FOLDER', name)

    def flush(self, name):
        file_stored = self.stored(name)
        if os.path.isfile(file_stored):
            return True

        file_cached = self.cached(name)
        if os.path.isfile(file_cached):
            shutil.move(file_cached, file_stored)
            return True
        else:
            return False



class Rand:
    @staticmethod
    def randstr(len=6):
        charlst = list(string.digits + string.letters[:26])
        random.shuffle(charlst)
        return ''.join(charlst[:len])