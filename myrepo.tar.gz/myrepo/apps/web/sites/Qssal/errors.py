# -*- coding:utf-8 -*-

class QssalError(Exception):
    pass