// for String
String.prototype.strip = function (){
    return this.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
}

String.prototype.lstrip = function(){
    return this.replace(/^\s\s*/, '');
}

String.prototype.rstrip = function(){
    return this.replace(/\s\s*$/, '');
}


// for Dialogs

function DialogGroup(maxz){
    this.maxz = arguments[0] ? arguments[0] : 1000;
    this.mask = (function(){
        var elem = $(document.createElement("div"));
        elem.css({
            "display": "none",
            "position": "absolute",
            "top": "0%",
            "left": "0%",
            "width": "100%",
            "height": "100%",
            "background-color": "grey",
            "-moz-opacity": "0.1",
            "opacity": ".10",
        });
        $("body").append(elem);
        return elem;
    })();

    this.add = (function(pattern){
        return new Dialog(pattern, this);
    });
}


function Dialog(pattern, dlggrp){
    var self = this;

    this.group = dlggrp;
    this.obj = $(pattern);

    this.act_onShow = function(){};
    this.act_onClose = function(){};
    this.act_onOk = function(){ return true; };
    this.act_onCancel = function(){ return true; };

    this.onShow = function(f){ self.act_onShow = f; };
    this.onClose = function(f){ self.act_onClose = f; };
    this.onOk = function(f){ self.act_onOk = f; };
    this.onCancel = function(f){ self.act_onCancel = f; };

    this.$ = function(pattern){
        return this.obj.find(pattern);
    };

    this.show = function(){
        this.group.mask.css("display", "block");
        this.group.mask.css("z-index", this.group.maxz++);

        this.obj.css("display", "block");
        this.obj.css("z-index", this.group.maxz++);

        this.act_onShow();
    };

    this.close = function(){
        this.act_onClose();

        this.obj.css("display", "none");
        this.group.maxz--;

        this.group.mask.css("display", "none");
        this.group.maxz--;
    };


    this.obj.find(".ok").click(function(){
        if(self.act_onOk() != false){
            self.close();
        }
    });

    this.obj.find(".cancel").click(function(){
        if(self.act_onCancel() != false){
            self.close();
        }
    });
}