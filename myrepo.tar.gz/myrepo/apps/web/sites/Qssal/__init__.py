# -*- coding:utf-8 -*-
from flask import Flask
import options
import utils

import os
from pyx.exceptionsx import *
from sms import BackStageSender


class Qssal(Flask):
    def __init__(self, name):
        Flask.__init__(self, name)
        self.config.from_object(options)

        self.config.update(
            dict(
                PATH=utils.Path(self)
            )
        )

        if getattr(Flask, "path", None):
            raise XNameClashError
        
    @property
    def path(self):
        return self.config["PATH"]


app = Qssal(__name__)
# print "static_root:", app.config.update(dict(STATIC_ROOT = '/'))
# print "static_url_path:", app.static_url_path
# from flask import url_for
# print url_for('static', filename='a.html')


file_database = app.path.root(app.config['DATABASE'])
if not os.path.isfile(file_database):
    from installer import homepage
else:
    # app.config.update()
    sms_service = BackStageSender(file_database)
    # sms_service.setDaemon(True)
    sms_service.start()

    from contextlib import closing
    import dboper, rolemgr

    with closing(dboper.get_connection()) as db:
        app.config.update(
            dict(
                ROLESET=rolemgr.get_roleset_updated(db)
                )
            )
    # setup handlers for requests
    from register import before_request, teardown_request
    # setup url-mapping handlers
    from views import homepage
    from views.auth import login
    from views.sheet import sheets_list
    from views.salary import salaries_list