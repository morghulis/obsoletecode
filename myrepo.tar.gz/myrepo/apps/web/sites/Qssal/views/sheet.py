# -*- coding:utf-8 -*-
from Qssal import app, sms_service
from Qssal.views import login_required, role_required
from Qssal.errors import *
from Qssal.data_sheet import SalarySheet, Qson

from flask import g, session, request
from flask import render_template, redirect, url_for
from werkzeug.utils import secure_filename

import uuid
from pyx.timex import TimeX
from pyx.hashx import HashX


@app.route('/sheet/list/', methods=['GET', 'POST'])
@login_required
@role_required(roles=['sheet_manager'])
def sheets_list():
    rs = g.db.execute(
        "select id, title, year, month, time_stamp, active from tbl_sheets \
            where user=? order by year desc, month desc, time_stamp desc",
            (session['user']['id'],)
        ).fetchall()
    g.sheets = [{
        'id': row[0],
        'title': row[1],
        'year': row[2],
        'month': row[3],
        'time_stamp': row[4],
        'active': row[5]
    } for row in rs]

    return render_template("sheets.html")



@app.route('/sheet/add/', methods=['GET', 'POST'])
@login_required
@role_required(roles=['sheet_manager'])
def sheet_add():

    def is_valid_args(year, month, filesheet):
                    
        def is_allowed_file(filename):
            if '.' in filename:
                if filename.rsplit('.')[-1] \
                    in app.config['ALLOW_UPLOAD_FILETYPES']:
                    # print "bbbbbbbbbbb"
                    return True
            g.err_message = "forbidden filetype"
            return False

        try:
            iyear = int(year)
            imonth = int(month)

            if iyear >= 1970 and iyear <= TimeX().local.year+1:
                if imonth >= 1 and imonth <= 12:
                    # print "aaaaaaaaaaaaaa"
                    return is_allowed_file(
                        secure_filename(filesheet.filename)
                        )

            g.err_message = "invalid year or month range"
        except:
            g.err_message = "invalid year or month given"
        return False


    def save_and_record_file(filesheet):
        # print "var:", filesheet
        # save file
        fileext = filesheet.filename.rsplit('.')[-1]
        uniname = "%s.%s"%(uuid.uuid4().get_hex(), fileext)
        uri = uniname


        fcached = app.path.cached(uri)
        fstored = app.path.stored(uri)

        # print "ccccccccccccccccccc"

        filesheet.save(fcached)

        # print "dddddddddddddddddddd"

        with file(fcached) as f:
            hashvalue = HashX(fobj=f).sha1.hexdigest()

        g.db.execute(
            "insert or ignore into tbl_files (uri, sha1) \
                values (?, ?)",
                (uri, hashvalue)
            )
        g.db.commit()
        rs = g.db.execute(
            "select id, uri from tbl_files where sha1=?",
                (hashvalue,)
            ).fetchall()
        if len(rs) == 1:
            if uri == rs[0][1]:
                app.path.flush(rs[0][1])
            fid = rs[0][0]
            uri = rs[0][1]
        else:
            g.err_message = "failed to save the uploaded file"
            return None

        # add records
        try:
            salarysheet = SalarySheet(app.path.stored(uri))
        except QssalError, e:
            g.err_message = "no sheet required in the uploaded file"
            return None

        if int(year) != salarysheet.year or int(month) != salarysheet.month:
            g.err_message = "unexpected year or month found in sheet"
            return None

        rs = g.db.execute("select max(id) from tbl_sheets").fetchall()
        
        sheetid = 1 if rs[0][0] is None else int(rs[0][0]) + 1

        rs = g.db.execute(
            "insert into tbl_sheets (id, file, user, year, month, title, pattern) \
                values (?, ?, ?, ?, ?, ?, ?)",
                (sheetid, fid, session['user']['id'], int(year), int(month),
                    salarysheet.title, salarysheet.pattern)
            )
        g.db.commit()

        for row in salarysheet.rows:
            username = row['姓名'.decode('utf-8')]
            g.db.execute(
                "insert into tbl_salary (sheet, user, data) \
                    select ?, id, ? from tbl_users where username=? \
                    union \
                        select ?, null, ? \
                    order by id desc limit 1",
                    (
                        sheetid, Qson.dump(row), username, 
                        sheetid, Qson.dump(row) 
                    )
                )
        g.db.commit()

        return sheetid


    if request.method == "POST":
        year = request.form["year"].strip()
        month = request.form["month"].strip()
        filesheet = request.files["filesheet"]

        # print "11111111111"

        if is_valid_args(year, month, filesheet):
            # print "22222222222"
            sheetid = save_and_record_file(filesheet)
            # print "3333333333333"
            if sheetid:
                return redirect(url_for("sheet_show", sheetid=sheetid))
    else:
        now = TimeX().local
        year = now.year
        month = now.month

    g.default_year = year
    g.default_month = month
    return render_template('sheet_add.html')


@app.route('/sheet/show/<int:sheetid>/', methods=['GET', 'POST'])
@login_required
@role_required(roles=['sheet_manager'])
def sheet_show(sheetid):
    rs = g.db.execute(
        "select title, pattern, active from tbl_sheets where \
            id=? and user=?",
            (sheetid, int(session['user']['id']))
        ).fetchall()
    if len(rs) == 1:
        title = rs[0][0]
        fields = Qson.load(rs[0][1])
        g.active = True if rs[0][2]==1 else False
    else:
        raise QssalError('todo: redirect error_page(no such sheet)')

    rs = g.db.execute(
        "select tbl_salary.user, tbl_salary.data, tbl_sms.cellphone, tbl_sms.reason \
            from tbl_salary left join tbl_sms on tbl_salary.id=tbl_sms.salary \
            where sheet=?", 
            (sheetid,)
        ).fetchall()
    # persons = [ Qson.load(row[1]) for row in rs ]
    if len(rs) > 0:
        persons = []
        for row in rs:
            # print row
            persons.append({
                    'user': row[0],
                    'data': Qson.load(row[1]),
                    'cellphone': row[2],
                    'sms_status': row[3]
                } )
            if not (row[0] > 0):
                g.invalid_user_reference = True
        # persons = [
        #     {
        #         'user':row[0], 
        #         'data': Qson.load(row[1])
        #     } 
        #     for row in rs ]
        # None in [ person['user'] for person in persons ]
    else:
        raise QssalError('todo: redirect error_page')

    return render_template(
        "sheet_show.html", sheetid=sheetid,
        title=title, fields=fields, persons=persons)



# @app.route('/sheet/edit/<int:sheetid>/', methods=['GET', 'POST'])
# @login_required
# @role_required(roles=['sheet_manager'])
# def sheet_edit(sheetid):
#     return ''


@app.route('/sheet/delete/<int:sheetid>/')
@login_required
@role_required(roles=['sheet_manager'])
def sheet_delete(sheetid):
    g.db.execute(
        "delete from tbl_sheets where user=? and id=? and active=0",
            (session['user']['id'], sheetid)
        )
    g.db.commit()
    return redirect(url_for("sheets_list"))


@app.route('/sheet/publish/<int:sheetid>/', methods=['POST'])
@login_required
@role_required(roles=['sheet_manager'])
def sheet_set(sheetid):
    def add_sms(sheetid):
        rs = g.db.execute(
            "select tbl_sheets.pattern from tbl_sheets where id=? and active=?",
                (sheetid, 1)
            ).fetchall()
        fields = Qson.load(rs[0][0])

        rs = g.db.execute(
            "select \
                tbl_users.cellphone, \
                tbl_salary.data, \
                tbl_salary.id \
                from tbl_salary, tbl_users where \
                    tbl_salary.sheet=? and tbl_users.id=tbl_salary.user",
                (sheetid, )
            ).fetchall()
        for row in rs:
            salary_id = row[2]
            cellphone = row[0] if row[0] else None
            values = Qson.load(row[1])

            fv = []

            for i in range(len(values)):
                if values[i] == '0.0':
                    continue
                fv.append('%s:%s'%(fields[i], values[i]))
            content = '\n'.join(fv)

            # print salary_id, cellphone, content

            g.db.execute(
                "insert or ignore into tbl_sms (salary, cellphone, content) \
                    values (?, ?, ?)",
                    (salary_id, cellphone, content)
                )
        g.db.commit()
        # app.config['SMS_SERVICE'].notify()
        
    if 'retry' in request.form:
        g.db.execute(
            "delete from tbl_sheets where id=?", 
            (sheetid,)
            )
        g.db.commit()
        return redirect(url_for('sheet_add'))
    else:
        rs = g.db.execute(
            "select * from tbl_sheets where id=? and active=1", (sheetid,)
            ).fetchall()
        if len(rs) == 1:
            return redirect(url_for("sheets_list"))

        g.db.execute(
            "update tbl_sheets set active=1 where user=? and id=? and \
                exists(\
                    select * from tbl_salary \
                        where tbl_salary.sheet=? and tbl_salary.user is null \
                    )=0",
                (session['user']['id'], sheetid, sheetid)
            )
        g.db.commit()

        add_sms(sheetid)

        sms_service.notify()
        return redirect(url_for("sheets_list"))


@app.route('/sheet/sms/<int:sheetid>/')
@login_required
@role_required(roles=['sheet_manager'])
def sheet_sms_resend(sheetid):
    g.db.execute(
        " update tbl_sms set \
            cellphone=( \
                select cellphone from tbl_users where \
                    cellphone != '' and \
                    id=(select user from tbl_salary where id=tbl_sms.salary) \
                ), \
            time_added=datetime('now', 'localtime') \
            where \
                time_submitted is null and cellphone is null and \
                (select sheet from tbl_salary where id=tbl_sms.salary)=?",
            (sheetid,)
        )
    
    g.db.commit()
    sms_service.notify()
    return redirect(url_for("sheets_list"))