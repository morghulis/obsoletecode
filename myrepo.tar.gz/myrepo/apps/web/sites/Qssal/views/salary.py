# -*- coding: utf-8 -*-
from Qssal import app
from Qssal.data_sheet import Qson
from Qssal.views import login_required
from flask import g, session
from flask import make_response, render_template


@app.route('/salary/<int:year>/')
@login_required
def salaries_list(year):
    rs = g.db.execute(
        "select tbl_sheets.pattern,tbl_salary.data, \
                tbl_sheets.year, tbl_sheets.month \
            from tbl_salary, tbl_sheets \
            where \
                tbl_sheets.active=1 and \
                tbl_salary.user=? and \
                tbl_sheets.year=? and \
                tbl_salary.sheet=tbl_sheets.id \
            order by tbl_sheets.year, tbl_sheets.month desc",
            (session['user']['id'], year)
        ).fetchall()

    salaries = [ 
            {
                'year': row[2],
                'month': row[3],
                'fieldnames': Qson.load(row[0]),
                'fieldvalues': Qson.load(row[1])
            }
            for row in rs
        ]

    rs = g.db.execute(
        "select min(tbl_sheets.year), max(tbl_sheets.year) from tbl_salary, tbl_sheets where \
            tbl_salary.user=? and tbl_salary.sheet=tbl_sheets.id",
            (session['user']['id'],)
        ).fetchall()
    g.yrange = { 'min': rs[0][0], 'max': rs[0][1] }
    print g.yrange
    g.year = year
    g.max_cols = 8

    return render_template("salaries.html", salaries=salaries)
    # return make_response("todo: list salary item in the specific year")