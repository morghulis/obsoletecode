# -*- coding:utf-8 -*-
from Qssal import app
from Qssal.rolemgr import get_user_roles_updated
from flask import render_template, redirect, url_for
from flask import g, session
from pyx.timex import TimeX

#
# Decorators
#
from functools import wraps

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        print "staitc folder:", url_for('static', filename='a.js')
        if "user" in session.keys():
            return f(*args, **kwargs)
        else:
            return redirect(url_for('login'))
    return wrapper


def role_required(roles=[]):
    def func(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            roleset = app.config["ROLESET"]

            urs = get_user_roles_updated(
                    g.db, roleset,
                    session['user']['id'], 
                    session["user"]["roles"]
                )
            session["user"]["roles"] = urs
            
            for rolename in roles:
                if not (rolename in urs.keys()):
                    return render_template("no_permission.html")
            return f(*args, **kwargs)

        return wrapper
    return func

#
# Some basic views
#
@app.route('/')
@login_required
def homepage():
    print "staitc folder:", url_for('static', filename='a.js')
    return redirect(url_for('salaries_list', year=TimeX().local.year))


@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404