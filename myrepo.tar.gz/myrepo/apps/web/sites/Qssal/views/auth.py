# -*- coding:utf-8 -*-
from Qssal import app
from Qssal.rolemgr import get_user_roles_updated
from Qssal.views import login_required, role_required
from Qssal.utils import Rand
from Qssal.rolemgr import get_roleset_updated
from Qssal.sms import sendsms


from flask import make_response
from flask import render_template, redirect, url_for
from flask import g, session, request

import re
import json

import pyx.logx
from pyx.randx import randomx
from pyx.timex import TimeX, Minute


logger = pyx.logx.getLogger('Qssal')


@app.route('/login/', methods=['GET', 'POST'])
def login():
    if "user" in session.keys():
        return redirect(url_for("homepage"))

    if request.method == "POST":
        bytel = request.form['bytel'].strip()
        

        # to do
        if bytel == "true":
            uname = request.form['phone'].strip()
            passwd = request.form['smscode'].strip()

            g.message = None
            g.bytel = bytel
            g.uname = uname
            print "bytel, uname:",g.bytel, g.uname

            if not ('sms_code' in session.keys()):
                g.message = "no identifying code1"
            if not g.message and not ('login' in session['sms_code'].keys()):
                g.message = "no identifying code2"

            if not g.message:

                dict4login = session['sms_code'].pop('login')

                if TimeX().utctime > dict4login['outdate']:
                    g.message = "smscode outdated"
                if not g.message and dict4login['cellphone'] != uname:
                    g.message = "cellphone changed"
                if not g.message and dict4login['smscode'] != passwd:
                    g.message = "incorrect identifying code"

            if not g.message:
                rs = g.db.execute(
                    "select id, username from tbl_users \
                        where cellphone=?",
                        (uname,)
                    ).fetchall()
                if len(rs) != 1:
                    g.message = "no such a phone bound"
                else:
                    uid = rs[0][0]
                    name = rs[0][1]
                    session["user"] = {
                        "id": uid,
                        "name": name,
                        "roles": get_user_roles_updated(
                            g.db, app.config["ROLESET"], uid
                            )
                    }
                    return redirect(url_for("homepage"))


            # return render_template('login.html')
        else:
            uname = request.form['uname'].strip()
            passwd = request.form['passwd'].strip()

            rs = g.db.execute(
                "select id, username from tbl_users \
                    where username=? and password=? and active=1",
                    (uname, passwd)
                ).fetchall()
            if len(rs) != 1:
                g.uname = uname
                if bytel == "true":
                    g.bytel = True
                g.message = "Invalid account/password"
            else:
                (uid, name) = rs[0]
                session["user"] = {
                    "id": uid,
                    "name": name,
                    "roles": get_user_roles_updated(
                        g.db, app.config["ROLESET"], uid
                        )
                }
                return redirect(url_for("homepage"))

    return render_template("login.html")


@app.route('/logout/')
@login_required
def logout():
    session.pop('user', None)
    return redirect(url_for("homepage"))


@app.route('/user/')
@login_required
def user_show():
    rs = g.db.execute(
        "select cellphone from tbl_users \
            where id=?",
            (session['user']['id'],)
        ).fetchall()
    g.cellphone = rs[0][0]
    return render_template("user_show.html")


@app.route('/user/add/', methods=['GET', 'POST'])
def user_add():
    if request.method == "POST":
        textusers = request.form['users'].strip()

        lines = []
        perfect = True

        for line in textusers.split(chr(10)):
            err_prefix = ''

            items = [ e.strip() 
                for e in re.split(
                    '[,，]'.decode('utf-8'), 
                    line.strip().strip(',').strip('，'.decode('utf-8'))) 
                ]

            cnt = len(items)
            print cnt
            if cnt > 0:
                username = items[0]
                cellphone = items[1] if cnt >= 2 else None
                password = items[2] if cnt >= 3 else app.config['DEFAULT_PASSWORD_FOR_NEW_USER']
                department = items[3] if cnt >= 4 else None

                if cellphone:
                    if re.match('^1[3|5|8][0-9]\d{8}$', cellphone):

                        rs = g.db.execute(
                            "select id from tbl_users where cellphone=?",
                                (cellphone,)
                            ).fetchall()
                        if len(rs) > 0:
                            err_prefix = "cellphone exists"
                    else:
                        err_prefix = "invalid cellphone"

                if err_prefix == '' :
                    rs = g.db.execute(
                        "select id from tbl_users where username=?",
                            (username,)
                        ).fetchall()
                    if len(rs) > 0:
                        err_prefix = "name exists"
                    else:
                        g.db.execute(
                            "insert into tbl_users (username, password, cellphone, description) \
                                values (?, ?, ?, ?)",
                                (username, password, cellphone, department)
                            )
                        g.db.commit()

            lines.append(line if err_prefix == '' else '[%s]%s'%(err_prefix, line))
            if err_prefix != '':
                perfect = False

        if perfect is True:
            result = { 'status': 'ok' }
        else:
            result = {
                'status': 'fail',
                'message': '\n'.join(lines)
            }

        return make_response(json.dumps(result))

    return render_template("user_add.html")



@app.route('/user/chgpwd/', methods=['POST'])
@login_required
def ajax_passwd_change():
    opwd = request.form['opwd'].strip()
    npwd = request.form['npwd'].strip()

    result = {}

    rs = g.db.execute(
        "select password from tbl_users where id=? and password=?",
            (session['user']['id'], opwd)
        ).fetchall()
    if len(rs) == 1:
        
        g.db.execute(
            "update tbl_users set password=? where id=?",
                (npwd, session['user']['id'])
            )
        g.db.commit()
        result = {
                    "status": "ok"
                }
    else:
        result = {
                    "status": "incorrect_oldpwd",
                    "message": "incorrect old password"
                }

    return make_response(json.dumps(result))


@app.route('/user/cellphone/get/')
@login_required
def ajax_get_cellphone():
    rs = g.db.execute(
        "select cellphone from tbl_users \
            where id=?",
            (session['user']['id'],)
        ).fetchall()

    if len(rs) == 1:
        result = {
            "status": "ok",
            "cellphone": rs[0][0] if rs[0][0] != None else ""
        }
    else:
        result = {
            "status": "fail",
            "message": "an error occurred in server" 
        }

    return make_response(json.dumps(result))


@app.route('/sms/code/login/')
def ajax_fetch_code4login():
    print 'ccccccccccccccccccccccccccccc'
    cellphone = request.args['cellphone']

    rs = g.db.execute(
        "select cellphone from tbl_users where cellphone=?",
            (cellphone,)
        ).fetchall()
    if len(rs) != 1:
        return make_response(json.dumps({
                'status': 'fail',
                'message': 'no such phone bound'
            }))

    smscode = randomx.randstr(4)
    if sendsms(cellphone, smscode)[0] != 'ok':
        return make_response(json.dumps({'status':'fail'}))

    session['sms_code'] = {
        'login': {
            'smscode': smscode,
            'cellphone': request.args['cellphone'],
            'outdate': (TimeX() + Minute(1)).utctime
        }
    }
    return make_response(
        json.dumps({
            "status": "ok",
            "cellphone": cellphone,
            "smscode": smscode
            })
        )


@app.route('/sms/code/bind/')
@login_required
def ajax_fetch_code4bind():
    smscode = randomx.randstr(4)
    cellphone = request.args['cellphone']

    if sendsms(cellphone, smscode)[0] != 'ok':
        return make_response(json.dumps({'status':'fail'}))

    session['sms_code'] = {
        'bind': {
            'smscode': smscode,
            'cellphone': request.args['cellphone'],
            'outdate': (TimeX() + Minute(1)).utctime
        }
    }


    return make_response(
        json.dumps({
            "status": "ok",
            "cellphone": cellphone,
            "smscode": smscode
            })
        )


@app.route('/user/bindphone/')
def ajax_bind_cellphone():

    if not ('bind' in session['sms_code']):
        return make_response(json.dumps({
            'status': 'fail',
            'message': 'no identifying code'
            }))

    result = []

    from_session = session['sms_code'].pop('bind')


    cellphone = request.args['cellphone']
    smscode = request.args['smscode']

    if cellphone != from_session['cellphone']:
        result = {
            'status': 'fail',
            'message': 'offensive action:cellphone changed'
        }
    if not result and TimeX().utctime > from_session['outdate']:
        result = {
            'status': 'fail',
            'message': 'identifying code outdated'
        }
    if not result and smscode.lower() != (from_session['smscode']).lower():
        result = {
            'status': 'fail',
            'message': 'incorrect identifying code'
        }
    if not result:
        g.db.execute(
            "update tbl_users set cellphone=? where id=?",
                (cellphone, session['user']['id'])
            )
        g.db.commit()
        result = {
            'status': 'ok'
        }

    return make_response(json.dumps(result))


@app.route('/user/list/')
@login_required
@role_required(roles=['user_manager'])
def users_list():
    rs = g.db.execute(
        "select id, username, cellphone, active from tbl_users where id > 1"
        ).fetchall()
    users = [{
        'id': row[0],
        'name': row[1],
        'cellphone': row[2],
        'active': True if row[3] == 1 else False
    } for row in rs ]

    return render_template("users_list.html", users=users)


@app.route('/user/toggle/<int:uid>/')
@login_required
@role_required(roles=['user_manager'])
def user_toggle(uid):
    g.db.execute(
        "update tbl_users set active=(active+1)%2 where id=? and id > 1",
            (uid, )
        ).fetchall()
    g.db.commit()

    return make_response(json.dumps({'status': 'ok'}))


@app.route('/user/edit/<int:uid>/')
@login_required
@role_required(roles=['user_manager'])
def user_edit(uid):
    rs = g.db.execute(
        "select id, username, cellphone from tbl_users where id=? and id > 1",
            (uid,)
        ).fetchall()
    if len(rs) != 1:
        return make_response("invasive access founc")

    user = {
        'id': rs[0][0],
        'name': rs[0][1],
        'cellphone': rs[0][2] if rs[0][2] is not None else ''
    }

    rs = g.db.execute(
        "select tbl_roles.id, tbl_roles.name, tbl_user_role.user \
            from tbl_roles left join tbl_user_role \
                on  tbl_roles.id=tbl_user_role.role and \
                    tbl_user_role.user=?",
            (uid,)
        ).fetchall()

    user['roles'] = [
        {
            'id': row[0],
            'name': row[1],
            'selected': False if row[2] is None else True
        } for row in rs ]

    g.uid = uid

    return render_template('user_edit.html', user=user)


@app.route('/user/edit/<int:uid>/', methods=["POST"])
@login_required
@role_required(roles=['user_manager'])
def ajax_user_edit(uid):
    def set_new_username(uid, newname):
        rs = g.db.execute(
            "select * from tbl_users where username=?",
                (newname,)
            ).fetchall()
        if len(rs) > 0:
            return make_response(json.dumps({
                    'status': 'fail',
                    'message': 'name used'
                }))

        g.db.execute(
            "update tbl_users set username=? where \
                id=? and id > 1 and exists(\
                    select id from tbl_users where \
                        username=?)=0",
                (newname, uid, newname)
            )
        g.db.commit()

        return make_response(json.dumps({
                'status': 'ok',
                'newname': newname
            }))

    def set_user_cellphone(uid, phn):
        
        if not re.match('^1[3|5|8][0-9]\d{8}$', phn):
            return make_response(json.dumps({
                    'status': 'ok',
                    'message': 'invalid phone number'
                }))

        g.db.execute(
            "update tbl_users set cellphone=? where id=? and id > 1",
                (phn, uid)
            )
        g.db.commit()

        return make_response(json.dumps({
                'status': 'ok',
                'message': 'changed in %s'%str(TimeX().local)
            }))

    def set_user_password(uid, passwd):
        g.db.execute(
            "update tbl_users set password=? where id=? and id > 1",
                (passwd, uid)
            )
        g.db.commit()

        return make_response(json.dumps({
                'status': 'ok',
                'message': 'changed in %s'%str(TimeX().local)
            }))
        pass

    def set_user_as_role(uid, rid, isadd):
        if uid <= 1:
            return make_response(json.dumps({
                    'status': 'fail',
                    'message': 'access forbidden'
                }))
        if isadd is True:
            g.db.execute(
                "insert into tbl_user_role (user, role) values (?, ?)",
                    (uid, rid)
                )
        else:
            g.db.execute(
                "delete from tbl_user_role where user=? and role=?",
                    (uid, rid)
                )
        g.db.commit()

        app.config["ROLESET"] = get_roleset_updated(
            g.db, app.config["ROLESET"])

        return make_response(json.dumps({
                'status': 'ok',
                'message': 'changed in %s'%str(TimeX().local)
            }))


    # print 'ajax_user_edit'

    print 'ajax_user_edit'
    if 'newname' in request.form.keys():
        return set_new_username(uid, request.form['newname'].strip())

    if 'cellphone' in request.form.keys():
        # print 'edit cellphone'
        return set_user_cellphone(uid, request.form['cellphone'].strip())

    if 'password' in request.form.keys():
        # print 'edit password'
        return set_user_password(uid, request.form['password'].strip())

    if 'roleid' in request.form.keys():
        # print 'edit roles'
        return set_user_as_role(
                    uid, request.form['roleid'],
                    True if request.form['assigned'] == 'true' else False
                    )

    return make_response(json.dumps({
            'status': 'fail',
            'message': 'unsupported action'
        }))


@app.route('/user/del/<int:uid>/')
@login_required
@role_required(roles=['user_manager'])
def user_del(uid):
    if uid > 1:
        try:
            g.db.execute('delete from tbl_users where id=?', (uid,))
            g.db.commit()

            result = { 'status': 'ok'}
        except:
            result = { 'status': 'fail', 'message': 'can not be deleted for its data existing,' }
    else:
        result = { 'status': 'fail', 'message': 'admin can not be deleted.' }
        
    return make_response(json.dumps(result))



