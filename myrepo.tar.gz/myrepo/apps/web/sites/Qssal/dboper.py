# -*- coding:utf-8 -*-
from Qssal import app
import sqlite3


_filedb = app.path.root(app.config['DATABASE'])

def get_connection(filedb=_filedb):
    return sqlite3.connect(filedb)