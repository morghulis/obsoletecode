# -*- coding:utf-8 -*-
import sys, os


DEBUG = True

SECRET_KEY = "development key" 

APP_FOLDER = os.path.realpath(
    os.path.join(
        os.path.dirname(os.path.realpath(sys.argv[0])), 
        "Qssal"
        )
    )

CACHE_FOLDER = os.path.realpath(
    os.path.join(APP_FOLDER, "./cached/")
    )

UPLOAD_FOLDER = os.path.realpath(
    os.path.join(APP_FOLDER, "./repository/")
    )

ALLOW_UPLOAD_FILETYPES = set(['xls', 'txt'])

DATABASE = "database.db"

SMS_SERVICE = "http://68.94.1.4:8081/sms/smsSendInterface.do"
SMS_USERNAME = "Qssal"
SMS_PASSWORD = "123"
SMS_SCANPERIOD_SECONDS = 300


DEFAULT_PASSWORD_FOR_NEW_USER = '111'