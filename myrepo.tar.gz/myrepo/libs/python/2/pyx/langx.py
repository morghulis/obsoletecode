# -*- coding:utf-8 -*-
import platform


__all__ = [
    "Python_Version",
    "enum",
    "printf"
]


Python_Version = platform.python_version()


def enum(typename, **kwargs):
    return type(typename, (object,), dict(**kwargs))()


def printf(*args):
    print ' '.join([arg.__str__() for arg in args])






#################################################
# FOR TEST
#
if __name__=='__main__':
    printf('3', '5', 'c', 3, 0.4236345, 'fsaz$d%d'%(9))
    
    fruit = enum('Fruit', apple=1, pear=2, orange=3)
    printf(fruit.orange)

    # f = fruit()
    # print f.orange