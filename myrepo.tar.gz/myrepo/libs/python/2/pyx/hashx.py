# -*- coding:utf-8 -*-
import hashlib
from exceptionsx import *


__all__ = [
    'HashX'
]


class HashX:
    """
    Usage: 
        HashX(smsg='vbajkgbwunjkzz').sha512.hexdigest()
        HashX(fobj=open('file1.bin').sha512.hexdigest()
    """
    class _Hash_Result:
        def __init__(self, hasher):
            self.hasher = hasher

        def hexdigest(self):
            return self.hasher.hexdigest()

    def __init__(self, smsg=None, fobj=None):
        if smsg and (not fobj):
            self.s = smsg
        elif fobj and (not smsg):
            self.f = fobj
        else:
            raise XInvalidParamsError("Single data source required")

    def _get_hash_result(self, algoname):
        algorithm = getattr(hashlib, algoname, None)
        if not algorithm:
            raise XInvalidParamsError("Unsupported algorithm asked")
        hasher = algorithm()

        f = getattr(self, 'f', None)
        if f:
            while True:
                data = f.read(10240)
                if not data:
                    break
                hasher.update(data)
        elif getattr(self, 's', None):
            hasher.update(self.s)
        else:
            raise XPanicError(
                "HashX: off-normal initialization exists"
                )

        return self._Hash_Result(hasher)

    #
    # for specified algorithm, eg. MD5, SHA-1, and so on.
    #
    def _hasher(algoname):
        return property(
            fget= lambda x: x._get_hash_result(algoname=algoname)
            )

    md5 = _hasher('md5')
    sha1 = _hasher('sha1')
    sha512 = _hasher('sha512')






#
# For test, ignored as using the module
#
if __name__=='__main__':
    print HashX(smsg='12345678899').md5.hexdigest()
    print HashX(smsg='12345678899').sha1.hexdigest()
    print HashX(smsg='12345678899').sha512.hexdigest()
    print help(HashX)