# -*- coding:utf-8 -*-
import logging


__all__ = [
    # functions
    'getLogger',

    # classes for config
    'FileConfig',
    'ConsoleConfig'
]


#
# Default configuration
#
default_level = logging.DEBUG
default_fmt = \
    "[%(asctime)s][%(name)s][%(levelname)s]: %(message)s"

# logging.basicConfig(level=default_level)


class _Log_Config(object):

    def __init__(self, handler=None, level=default_level, fmt=default_fmt):
        if self.__class__ is _Log_Config:
            raise NotImplementedError

        self.handler = handler

        self.handler.setFormatter(logging.Formatter(fmt))
        self.handler.setLevel(level)



class FileConfig(_Log_Config):
    def __init__(self, logfile=None, level=default_level, fmt=default_fmt):
        _Log_Config.__init__(self, 
            handler=logging.FileHandler(logfile), 
            level=level, fmt=fmt)

class ConsoleConfig(_Log_Config):
    def __init__(self, level=default_level, fmt=default_fmt):
        _Log_Config.__init__(self, 
            handler=logging.StreamHandler(), 
            level=level, fmt=fmt)


def getLogger(name=None, configs=None):
    logger = logging.getLogger(name)
    logger.setLevel(default_level)
    if configs:
        for config in configs:
            logger.addHandler(config.handler)
    return logger





#
# For test, ignored as using the module
#
if __name__=='__main__':
    configs = []
    # configs.append(
    #     FileConfig(
    #         logfile='file.log', 
    #         fmt="[%(asctime)s][%(name)s][%(levelname)s]: %(message)s"
    #         )
    #     )

    cc = ConsoleConfig()
    # cc.setLevel(logging.NOTSET)

    configs.append(cc)
    logger = getLogger('logf', configs)

    log2 = getLogger('azh', configs)
    log2.warn("fdsfgahha")



    logger.debug("first line")
    logger.warn("first line")

    # logging.basicConfig(level=default_level)


    # logger = logging.getLogger('gszbxzb')
    # minlvl = 0

    # handler = logging.StreamHandler()
    # handler.setFormatter(logging.Formatter(default_fmt))

    # logger.addHandler(handler)
    # logger.setLevel(logging.DEBUG)
    # # if configs:
    # #     for config in configs:
    # #         logger.addHandler(config.handler)
    # #         minlvl = config.level if config.level < minlvl else minlvl
    # # logger.setLevel(logging.NOTSET)


    # logger.debug("debug first line")
    # logger.warn("first line")


    # import hashx

    # print help(hashx)


    # def worker():
    #     log3 = getLogger('logf')
    #     log3.debug('from child thread')

    # import threading

    # t = threading.Thread(target=worker)
    # t.start()
    # logger.info('from parent thread')



    pass