# -*- coding:utf-8 -*-
import time
import collections
from exceptionsx import *


__all__ = [
    'TimeX',
    'Year', 'Month', 'Week', 'Day',
    'Hour', 'Minute', 'Second'
]


class Second(object):
    unit = 1
    def __init__(self, i):
        self.value = i * self.unit

class Minute(Second):
    unit = 60

class Hour(Second):
    unit = 60*60

class Day(Second):
    unit = 24*60*60

class Week(Second):
    unit = 7*24*60*60

class Month(object):
    unit = 1
    def __init__(self, i):
        self.value = i * self.unit

class Year(Month):
    unit = 12


class TimeX:
    def __init__(self, str_localtime=None, float_utctime=None):
        if str_localtime and not float_utctime:
            self.__utctime = time.mktime(
                _fstr2tm(str_localtime)
                )
            pass
        elif float_utctime and not str_localtime:
            self.__utctime = float_utctime
        elif not str_localtime and not float_utctime:
            self.__utctime = time.time()
        else:
            raise XInvalidParamsError(
                'Single time representation required')

    @property
    def utctime(self):
        return self.__utctime

    @property
    def gm(self):
        return _Struct_Time(time.gmtime(self.__utctime))

    @property
    def local(self):
        return _Struct_Time(time.localtime(self.__utctime))
        

    def _add_or_sub_(self, i, func):
        if isinstance(i, Second):
            return TimeX(float_utctime=func(self.__utctime, i.value))
        elif isinstance(i, Month):
            tm = time.localtime(self.__utctime)
            mons = func(tm.tm_year*12 + tm.tm_mon, i.value)

            return TimeX(
                str_localtime=_time2fstr(
                    year=mons/12, month=mons%12, day=tm.tm_mday,
                    hour=tm.tm_hour, minute=tm.tm_min, second=tm.tm_sec)
                )
        elif isinstance(i, TimeX):
            return TimeX(float_utctime=func(self.utctime, i.utctime))
        else:
            raise XInvalidParamsError("Unsupported type given")

    def __add__(self, other):
        return self._add_or_sub_(other, lambda x, y: x+y)

    def __sub__(self, other):
        return self._add_or_sub_(other, lambda x, y: x-y)

    def __iadd__(self, other):
        return self.__add__(other)

    def __isub__(self, other):
        return self.__sub__(other)

    def _rich_cmp_(self, other, func):
        if isinstance(other, TimeX):
            return func(self.__utctime, other.utctime)
        raise XInvalidParamsError()

    def __lt__(self, other):
        return self._rich_cmp_(other, lambda x, y: x < y)

    def __le__(self, other):
        return self._rich_cmp_(other, lambda x, y: x <= y)

    def __eq__(self, other):
        return self._rich_cmp_(other, lambda x, y: x == y)

    def __ne__(self, other):
        return self._rich_cmp_(other, lambda x, y: x != y)

    def __gt__(self, other):
        return self._rich_cmp_(other, lambda x, y: x > y)

    def __ge__(self, other):
        return self._rich_cmp_(other, lambda x, y: x >= y)



def _time2fstr(
        year=0, month=1, day=1, hour=0, minute=0, second=0, isdst=0
        ):
    return "%04d-%02d-%02d %02d:%02d:%02d"%(
        year, month, day, hour, minute, second)

def _fstr2tm(fstr):
    return time.strptime(fstr, '%Y-%m-%d %H:%M:%S')

def _tm2fstr(tm):
    return time.strftime('%Y-%m-%d %H:%M:%S', tm)

def _time2tm(year=0, month=1, day=1, hour=0, minute=0, second=0, isdst=0):
    return _fstr2tm(
        _time2fstr(
            year=year, month=month, day=day, 
            hour=hour, minute=minute, second=second,
            isdst=isdst
            )
        )

_struct_timex = collections.namedtuple('_struct_timex',
    [
        'year', 'month', 'day',
        'hour', 'minute', 'second',
        'wday', 'yday', 'isdst'
    ]
)

class _Struct_Time(_struct_timex):
    def __new__(self, tm):
        self._tm = tm
        return _struct_timex.__new__(self,
            year=tm.tm_year, month=tm.tm_mon, day=tm.tm_mday,
            hour=tm.tm_hour, minute=tm.tm_min, second=tm.tm_sec,
            wday=tm.tm_wday, yday=tm.tm_yday, isdst=tm.tm_isdst)

    def tostr(self):
        return _tm2fstr(self._tm)

    def __str__(self):
        return self.tostr()






##################################################
# FOR TEST
#

if __name__=='__main__':
    print Year(2).value
    print Month(2).value
    print Week(3).value
    print Day(7).value*3
    print Day(7).value
    print Hour(24).value

    st = _Struct_Time(time.localtime(time.time()))

    print dir(st)
    print st.year
    print st

    print TimeX().gm, TimeX().local
    print TimeX().gm.day, TimeX().local.minute

    print (TimeX() + Year(2)).gm
    print (TimeX() + Year(2)).local
    print (TimeX('2014-02-02 23:43:10')+Year(1)+Day(31)).local

    t = TimeX()

    t += Month(5)
    print t.gm