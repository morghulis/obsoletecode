# -*- coding:utf-8 -*-
class XError(Exception):pass

class XPanicError(XError):pass
class XInvalidParamsError(XError):pass
class XNameClashError(XError):pass