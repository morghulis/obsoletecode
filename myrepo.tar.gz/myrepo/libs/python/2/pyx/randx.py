# -*- coding:utf-8 -*-
import random
import string


_chset = '%s%s'%(string.digits, string.letters)
_mincur = 0
_maxcur = len(_chset) - 1


class randomx:
    @staticmethod
    def randstr(len):
        lst = []
        for i in range(len):
            lst.append(_chset[random.randint(_mincur, _maxcur)])
        return ''.join(lst)